// cmd
// powershell -ExecutionPolicy Bypass -File ".\[1] WinUtil.ps1"
// powershell -ExecutionPolicy Bypass -File ".\[2] Windows_Optimisation_Pack.ps1"