1) Open the folder where your "Counter-Strike Source" game is installed.
2) Paste the cstrike folder.