1) Open the folder where your Counter-Strike 1.6 game is installed.
2) Paste the cstrike folder.